dqSignature();

function dqSignature() {
    
    var signature = '';
    
    signature += "\n" + '   Website designed by https://designquest.com.hk/';
    signature += "\n" + '     ___  ___ ___ ___ ___ _  _    ___  _   _ ___ ___ _____ ';
    signature += "\n" + '    |   \\| __/ __|_ _/ __| \\| |  / _ \\| | | | __/ __|_   _|';
    signature += "\n" + '    | |) | _|\\__ \\| | (_ | .` | | (_) | |_| | _|\\__ \\ | |  ';
    signature += "\n" + '    |___/|___|___/___\\___|_|\\_|  \\__\\_\\\\___/|___|___/ |_|  ';
    
    console.group('Welcome to the real world!');
    console.log(signature);
    console.groupEnd();
    
}
