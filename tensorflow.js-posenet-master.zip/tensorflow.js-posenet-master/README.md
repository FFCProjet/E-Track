# TensorflowJS posenet study project
It is my study project of TensorflowJS posenet.<br>

![TensorflowJS posenet sample](https://designquest.com.hk/demo/tensorflow-posenet/readme/sample1.png)


Demo page: https://designquest.com.hk/demo/tensorflow-posenet/<br>
Source: https://github.com/tensorflow/tfjs-models/tree/master/posenet

## Note
1. Try to load video from other server, but estimateMultiplePoses not work. Find out the video must save in same server.

## Install
    npm install
    
## Start
Start development server on http://localhost:8080<br>
Browser will auto reload when js, scss, html changed.

    gulp
